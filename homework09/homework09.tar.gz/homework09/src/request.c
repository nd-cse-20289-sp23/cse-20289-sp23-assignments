/* request.c: Make HTTP Requests */

#include "request.h"

#include "macros.h"
#include "socket.h"

#include <stdlib.h>
#include <string.h>

/* Constants */

#define HOST_DELIMITER  "://"
#define PATH_DELIMITER  '/'
#define PORT_DELIMITER  ':'

/* Functions */

/**
 * Construct Request structure by parsing URL string into separate host, port,
 * and path components.
 *
 * @param   url         URL string to parse.
 *
 * @return  Request structure.
 **/
Request *   request_create(const char *url) {
    /* TODO: Copy data to local buffer */

    /* TODO: Skip scheme to host */

    /* TODO: Split host:port from path */

    /* TODO: Split host and port */

    /* TODO: Allocate Request structure */

    /* TODO: Copy components to URL structure */

    return NULL;
}

/**
 * Deallocate Request structure.
 *
 * @param   request     Request structure to deallocate.
 **/
void	    request_delete(Request *request) {
}

/**
 * Make a HTTP request and write the contents of the response to the specified
 * stream.
 *
 * @param   url         Make a HTTP request to this URL.
 * @param   stream      Write the contents of response to this stream.
 *
 * @return  -1 on error, otherwise the number of bytes written.
 **/
ssize_t     request_stream(Request *request, FILE *stream) {
    /* TODO: Connect to remote host and port */

    /* TODO: Send request to server */

    /* TODO: Read response status from server */

    /* TODO: Read response headers from server */

    /* TODO: Read response body from server */

    /* TODO: Close connection */

    /* TODO: Return number of bytes written and check if it matches Content-Length */

    return -1;
}

/* vim: set sts=4 sw=4 ts=8 expandtab ft=c: */
